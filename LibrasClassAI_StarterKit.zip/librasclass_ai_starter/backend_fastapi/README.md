# Backend FastAPI — LibrasClass AI

## Rodar
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Endpoints
- POST `/translate`
- GET `/dictionary/signs`
- GET `/dictionary/phrases`
- GET `/lessons`
- POST `/lessons`
