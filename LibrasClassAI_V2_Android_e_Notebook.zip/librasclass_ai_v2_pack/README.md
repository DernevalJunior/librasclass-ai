# LibrasClass AI V2 (Android + Notebook)

Pacote com:
- `app_flutter_v2/` (Flutter melhorado, fallback local)
- `backend_fastapi/` (API de tradução MVP)
- `notebook_web_demo_streamlit/` (versão para notebook/PC)

## Nota
Avatar Unity real continua pendente de modelo 3D + animações. Nesta V2 há placeholder visual funcional.
