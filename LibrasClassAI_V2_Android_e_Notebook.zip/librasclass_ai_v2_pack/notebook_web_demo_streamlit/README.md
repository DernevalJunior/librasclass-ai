# Notebook/PC (Streamlit)
streamlit run app.py
