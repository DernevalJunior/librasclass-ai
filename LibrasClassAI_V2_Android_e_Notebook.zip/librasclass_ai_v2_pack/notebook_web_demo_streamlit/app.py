
import json, re
from pathlib import Path
import requests
import streamlit as st
st.set_page_config(page_title="LibrasClass AI Notebook", page_icon="🧏", layout="wide")
BASE=Path(__file__).parent
SIGNS=json.load(open(BASE/"data"/"signs.json",encoding="utf-8"))
PHRASES=json.load(open(BASE/"data"/"phrases.json",encoding="utf-8"))
STOP={"vamos","vou","vai","o","a","os","as","de","do","da","e","no","na","nos","nas"}
def n(s):
    s=s.lower().strip()
    rep={"ç":"c","á":"a","à":"a","ã":"a","â":"a","é":"e","ê":"e","í":"i","ó":"o","ô":"o","õ":"o","ú":"u"}
    for k,v in rep.items(): s=s.replace(k,v)
    s=re.sub(r'[\.,;:!?"()\[\]{}]', ' ', s)
    return re.sub(r'\s+',' ',s).strip()
IDX={n(x["word_pt"]):x for x in SIGNS}
def local_translate(text):
    toks=[t for t in n(text).split() if t and t not in STOP]
    gloss=[]; anim=[]; miss=[]
    for t in toks:
        if t in IDX: gloss.append(IDX[t]["gloss"]); anim.append(IDX[t]["animation"])
        else: gloss.append(t.upper()); anim.append("spell"); miss.append(t)
    return {"gloss":" ".join(gloss),"animations":anim,"missing":miss,"source":"local"}
st.title("🧏 LibrasClass AI — Notebook")
api_url=st.sidebar.text_input("API URL","http://localhost:8000")
use_api=st.sidebar.toggle("Tentar API online", value=True)
for p in PHRASES:
    if st.sidebar.button(p["phrase"], key=str(p["id"])): st.session_state["text"]=p["phrase"]
txt=st.text_area("Digite a frase", value=st.session_state.get("text","Hoje vamos estudar frações"), height=90)
if st.button("Traduzir", type="primary"):
    res=None; err=None
    if use_api:
        try:
            r=requests.post(api_url.rstrip("/")+"/translate", json={"text":txt}, timeout=5); r.raise_for_status(); res=r.json()
        except Exception as e: err=str(e)
    if res is None: res=local_translate(txt)
    st.success(f"Fonte: {res.get('source','?')}")
    st.subheader("GLOSS"); st.code(res.get("gloss","-"))
    st.subheader("Animações"); st.write(" → ".join(res.get("animations",[])) or "-")
    if res.get("missing"): st.warning("Termos faltantes: " + ", ".join(res["missing"]))
    if err: st.caption("API falhou, fallback local usado: " + err)
st.markdown("---")
st.info("Versão notebook usa avatar placeholder textual (sequência de animações).")
