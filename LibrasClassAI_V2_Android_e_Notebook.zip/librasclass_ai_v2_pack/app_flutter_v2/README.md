# Flutter V2 Source Overlay
Use com workflow que cria `flutter create build_app` e copia `lib/assets/pubspec.yaml` para dentro de `build_app`.
