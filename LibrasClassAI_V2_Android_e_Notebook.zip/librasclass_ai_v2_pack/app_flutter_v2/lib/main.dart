
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/api_service.dart';
import 'screens/home_screen.dart';
import 'screens/translator_screen.dart';
import 'screens/lessons_screen.dart';
import 'screens/dictionary_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/lesson_player_screen.dart';
void main()=>runApp(const App());
class App extends StatelessWidget{
  const App({super.key});
  @override Widget build(BuildContext context)=>Provider<ApiService>(
    create: (_)=>ApiService(),
    child: MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "LibrasClass AI",
      theme: ThemeData(useMaterial3:true,colorSchemeSeed: Colors.blue),
      routes: {
        "/":(_)=>const HomeScreen(),
        "/translator":(_)=>const TranslatorScreen(),
        "/lessons":(_)=>const LessonsScreen(),
        "/dictionary":(_)=>const DictionaryScreen(),
        "/favorites":(_)=>const FavoritesScreen(),
        "/lesson_player":(_)=>const LessonPlayerScreen(),
      },
    ),
  );
}
