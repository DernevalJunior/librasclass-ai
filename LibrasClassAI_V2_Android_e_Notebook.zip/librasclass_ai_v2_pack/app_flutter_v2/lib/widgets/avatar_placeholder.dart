
import 'package:flutter/material.dart';
class AvatarPlaceholder extends StatelessWidget {
  final List<String> animations; final String source; final bool apiOnline;
  const AvatarPlaceholder({super.key, required this.animations, required this.source, required this.apiOnline});
  @override
  Widget build(BuildContext context){
    return Container(
      height: 260, padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.blue.shade50,borderRadius: BorderRadius.circular(16),border: Border.all(color: Colors.blue.shade100)),
      child: Column(children: [
        Row(children:[
          const CircleAvatar(child: Icon(Icons.accessibility_new)),
          const SizedBox(width:8),
          const Expanded(child: Text("LIA (placeholder)", style: TextStyle(fontWeight: FontWeight.bold))),
          Chip(label: Text(apiOnline ? "API" : "LOCAL"))
        ]),
        const Spacer(),
        const Icon(Icons.sign_language, size: 64),
        const SizedBox(height: 8),
        Text(animations.isEmpty ? "Nenhuma animação" : animations.join(" → "), textAlign: TextAlign.center),
        const Spacer(),
        Text(source.isEmpty ? "" : "Fonte: $source")
      ]),
    );
  }
}
