
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'api_config.dart';
class ApiService {
  final http.Client c;
  ApiService({http.Client? client}) : c = client ?? http.Client();
  Future<bool> health() async { try { final r=await c.get(Uri.parse("${ApiConfig.baseUrl}/health")); return r.statusCode==200; } catch (_) { return false; } }
  Future<Map<String,dynamic>> translate(String text) async {
    final r=await c.post(Uri.parse("${ApiConfig.baseUrl}/translate"), headers: {"Content-Type":"application/json"}, body: jsonEncode({"text":text}));
    if(r.statusCode>=200&&r.statusCode<300) return jsonDecode(r.body);
    throw Exception("API /translate ${r.statusCode}");
  }
  Future<List<dynamic>> phrases() async {
    final r=await c.get(Uri.parse("${ApiConfig.baseUrl}/dictionary/phrases"));
    if(r.statusCode>=200&&r.statusCode<300) return jsonDecode(r.body);
    throw Exception("API /dictionary/phrases ${r.statusCode}");
  }
  Future<List<dynamic>> lessons() async {
    final r=await c.get(Uri.parse("${ApiConfig.baseUrl}/lessons"));
    if(r.statusCode>=200&&r.statusCode<300) return jsonDecode(r.body);
    throw Exception("API /lessons ${r.statusCode}");
  }
}
