
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
class LocalFallbackService {
  static const stop={"vamos","vou","vai","o","a","os","as","de","do","da","e","no","na","nos","nas"};
  Future<Map<String,dynamic>> translateLocal(String text) async {
    final raw = await rootBundle.loadString('assets/data/signs.json');
    final arr = jsonDecode(raw) as List<dynamic>;
    final idx = <String,Map<String,dynamic>>{};
    for(final x in arr){ final m=x as Map<String,dynamic>; idx[_n(m["word_pt"].toString())]=m; }
    final norm = _n(text);
    final toks = norm.split(' ').where((t)=>t.isNotEmpty && !stop.contains(t)).toList();
    final gloss=<String>[]; final anim=<String>[]; final miss=<String>[]; final signs=<String>[];
    for(final t in toks){
      if(idx.containsKey(t)){ final m=idx[t]!; gloss.add(m["gloss"].toString()); anim.add(m["animation"].toString()); signs.add(t); }
      else { gloss.add(t.toUpperCase()); anim.add("spell"); signs.add("spell:$t"); miss.add(t); }
    }
    return {"normalized":norm,"gloss":gloss.join(" "),"animations":anim,"missing":miss,"signs":signs,"source":"local"};
  }
  String _n(String s){ var o=s.toLowerCase().trim();
    const rep={"ç":"c","á":"a","à":"a","ã":"a","â":"a","é":"e","ê":"e","í":"i","ó":"o","ô":"o","õ":"o","ú":"u"};
    rep.forEach((k,v){o=o.replaceAll(k,v);});
    o=o.replaceAll(RegExp(r'[\.,;:!?"()\[\]{}]'),' ');
    o=o.replaceAll(RegExp(r'\s+'),' ').trim();
    return o;
  }
}
