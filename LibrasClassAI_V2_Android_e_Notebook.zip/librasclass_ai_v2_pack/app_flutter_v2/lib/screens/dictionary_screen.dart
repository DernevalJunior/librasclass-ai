
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
class DictionaryScreen extends StatefulWidget{ const DictionaryScreen({super.key}); @override State<DictionaryScreen> createState()=>_DictionaryScreenState(); }
class _DictionaryScreenState extends State<DictionaryScreen>{
  bool loading=true; String error=""; List<dynamic> items=[];
  @override void initState(){ super.initState(); load(); }
  Future<void> load() async { setState((){loading=true;error="";}); try{ items=await context.read<ApiService>().phrases(); } catch(e){ error="$e"; } if(mounted) setState(()=>loading=false); }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Dicionário / Frases"), actions:[IconButton(onPressed:load, icon: const Icon(Icons.refresh))]),
    body: loading? const Center(child:CircularProgressIndicator())
      : error.isNotEmpty ? Center(child:Padding(padding: const EdgeInsets.all(16), child: Text("Falha: $error", textAlign: TextAlign.center)))
      : ListView.separated(itemCount: items.length, separatorBuilder:(_,__)=>const Divider(height:1), itemBuilder:(c,i){ final p=items[i] as Map<String,dynamic>; return ListTile(title: Text(p["phrase"].toString()), subtitle: Text(p["category"].toString()), trailing: const Icon(Icons.chevron_right), onTap: ()=>Navigator.pushNamed(c,"/translator")); }),
    bottomNavigationBar: const _Bottom(3),
  );
}
class _Bottom extends StatelessWidget{ final int i; const _Bottom(this.i,{super.key});
  @override Widget build(BuildContext c)=>NavigationBar(selectedIndex:i,onDestinationSelected:(x){ final r=["/","/translator","/lessons","/dictionary","/favorites"]; Navigator.pushNamed(c,r[x]);},
  destinations: const [NavigationDestination(icon: Icon(Icons.home),label:"Home"),NavigationDestination(icon: Icon(Icons.translate),label:"Traduzir"),NavigationDestination(icon: Icon(Icons.menu_book),label:"Aulas"),NavigationDestination(icon: Icon(Icons.search),label:"Dicionário"),NavigationDestination(icon: Icon(Icons.star),label:"Favoritos")]); }
