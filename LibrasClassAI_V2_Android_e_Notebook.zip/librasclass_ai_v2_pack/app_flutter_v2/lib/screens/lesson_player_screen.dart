
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/local_fallback_service.dart';
import '../widgets/avatar_placeholder.dart';

class LessonPlayerScreen extends StatefulWidget{ const LessonPlayerScreen({super.key}); @override State<LessonPlayerScreen> createState()=>_LessonPlayerScreenState(); }
class _LessonPlayerScreenState extends State<LessonPlayerScreen>{
  final local=LocalFallbackService(); int idx=0; bool loading=false; bool apiOnline=false; String gloss="",source=""; List<String> anim=[];
  @override void initState(){ super.initState(); _check(); }
  Future<void> _check() async { final ok=await context.read<ApiService>().health(); if(mounted)setState(()=>apiOnline=ok); }
  Future<void> play(Map<String,dynamic> lesson) async {
    setState(()=>loading=true);
    final text=((lesson["items"] as List)[idx] as Map<String,dynamic>)["text"].toString();
    Map<String,dynamic> r;
    try{
      if(apiOnline){ try{ r=await context.read<ApiService>().translate(text);} catch(_){ r=await local.translateLocal(text); apiOnline=false; } }
      else { r=await local.translateLocal(text); }
      if(mounted)setState((){ gloss=r["gloss"]??""; source=r["source"]??""; anim=(r["animations"] as List).map((e)=>e.toString()).toList(); });
    } finally { if(mounted)setState(()=>loading=false); }
  }
  @override Widget build(BuildContext c){
    final lesson = ModalRoute.of(c)!.settings.arguments as Map<String,dynamic>;
    final items = lesson["items"] as List<dynamic>;
    final current=(items[idx] as Map<String,dynamic>)["text"].toString();
    return Scaffold(
      appBar: AppBar(title: Text(lesson["title"].toString())),
      body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
        Card(child: ListTile(title: Text("Item ${idx+1}/${items.length}"), subtitle: Text(current))),
        AvatarPlaceholder(animations: anim, source: source, apiOnline: apiOnline),
        Card(child: ListTile(title: const Text("GLOSS"), subtitle: Text(gloss.isEmpty?"-":gloss))),
        const Spacer(),
        Row(children:[
          Expanded(child: OutlinedButton(onPressed: idx>0?(){setState(()=>idx--);} : null, child: const Text("Anterior"))),
          const SizedBox(width:8),
          Expanded(child: ElevatedButton.icon(onPressed: loading?null:()=>play(lesson), icon: const Icon(Icons.play_arrow), label: Text(loading?"...":"Sinalizar"))),
          const SizedBox(width:8),
          Expanded(child: OutlinedButton(onPressed: idx<items.length-1?(){setState(()=>idx++);} : null, child: const Text("Próximo"))),
        ])
      ])),
    );
  }
}
