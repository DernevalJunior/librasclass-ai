
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/local_fallback_service.dart';
import '../widgets/avatar_placeholder.dart';

class TranslatorScreen extends StatefulWidget {
  const TranslatorScreen({super.key});
  @override State<TranslatorScreen> createState()=>_TranslatorScreenState();
}
class _TranslatorScreenState extends State<TranslatorScreen> {
  final ctrl = TextEditingController(text: "Hoje vamos estudar frações");
  final local = LocalFallbackService();
  bool loading=false, apiOnline=false;
  String gloss="", source="", status="Carregando...";
  List<String> anim=[]; List<String> missing=[];
  @override void initState(){ super.initState(); _check(); }
  Future<void> _check() async { final ok=await context.read<ApiService>().health(); if(mounted)setState((){apiOnline=ok; status=ok?"API online":"API offline (fallback local)";}); }
  Future<void> translate() async {
    setState(()=>loading=true);
    try{
      Map<String,dynamic> r;
      if(apiOnline){ try { r=await context.read<ApiService>().translate(ctrl.text);} catch(_){ r=await local.translateLocal(ctrl.text); apiOnline=false; } }
      else { r=await local.translateLocal(ctrl.text); }
      if(!mounted) return;
      setState((){ gloss=r["gloss"]??""; source=r["source"]??""; anim=(r["animations"] as List).map((e)=>e.toString()).toList(); missing=(r["missing"] as List).map((e)=>e.toString()).toList(); status="OK"; });
    } catch(e){ if(mounted) setState(()=>status="Erro: $e"); }
    finally { if(mounted) setState(()=>loading=false); }
  }
  @override Widget build(BuildContext context){
    final quick=["Bom dia turma","Abram o caderno","Hoje vamos estudar frações","Prestem atenção no quadro"];
    return Scaffold(
      appBar: AppBar(title: const Text("Tradutor"), actions:[IconButton(onPressed:_check, icon: const Icon(Icons.refresh))]),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children:[
          TextField(controller: ctrl, minLines:1, maxLines:3, decoration: const InputDecoration(labelText:"Digite a frase", border: OutlineInputBorder())),
          const SizedBox(height:8),
          Wrap(spacing:8, runSpacing:8, children: quick.map((q)=>ActionChip(label: Text(q), onPressed:(){setState(()=>ctrl.text=q); translate();})).toList()),
          const SizedBox(height:8),
          SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: loading?null:translate, icon: const Icon(Icons.translate), label: Text(loading?"Traduzindo...":"Traduzir"))),
          const SizedBox(height:12),
          AvatarPlaceholder(animations: anim, source: source, apiOnline: apiOnline),
          const SizedBox(height:8),
          Card(child: ListTile(title: const Text("Status"), subtitle: Text(status))),
          Card(child: ListTile(title: const Text("GLOSS"), subtitle: Text(gloss.isEmpty?"-":gloss))),
          Card(child: ListTile(title: const Text("Termos faltantes"), subtitle: Text(missing.isEmpty?"Nenhum":missing.join(", "))))
        ]),
      ),
      bottomNavigationBar: const _Bottom(1),
    );
  }
}
class _Bottom extends StatelessWidget{
  final int i; const _Bottom(this.i,{super.key});
  @override Widget build(BuildContext c)=>NavigationBar(
    selectedIndex:i,
    onDestinationSelected:(x){ final r=["/","/translator","/lessons","/dictionary","/favorites"]; Navigator.pushNamed(c,r[x]);},
    destinations: const [
      NavigationDestination(icon: Icon(Icons.home), label: "Home"),
      NavigationDestination(icon: Icon(Icons.translate), label: "Traduzir"),
      NavigationDestination(icon: Icon(Icons.menu_book), label: "Aulas"),
      NavigationDestination(icon: Icon(Icons.search), label: "Dicionário"),
      NavigationDestination(icon: Icon(Icons.star), label: "Favoritos"),
    ],
  );
}
