
import 'package:flutter/material.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context){
    final items=[("Tradutor","/translator",Icons.translate),("Aulas","/lessons",Icons.menu_book),("Dicionário","/dictionary",Icons.search),("Favoritos","/favorites",Icons.star)];
    return Scaffold(
      appBar: AppBar(title: const Text("LibrasClass AI")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.builder(
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.25),
          itemBuilder:(c,i){ final it=items[i];
            return InkWell(
              onTap:()=>Navigator.pushNamed(context,it.$2),
              child: Ink(
                decoration: BoxDecoration(color: Colors.blue.shade50,borderRadius: BorderRadius.circular(16),border: Border.all(color: Colors.blue.shade100)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children:[Icon(it.$3,size:36), const SizedBox(height:8), Text(it.$1, style: const TextStyle(fontWeight: FontWeight.bold))]),
              ),
            );
          }),
      ),
      bottomNavigationBar: const _Bottom(0),
    );
  }
}
class _Bottom extends StatelessWidget{
  final int i; const _Bottom(this.i,{super.key});
  @override Widget build(BuildContext c)=>NavigationBar(
    selectedIndex:i, onDestinationSelected:(x){ final r=["/","/translator","/lessons","/dictionary","/favorites"]; Navigator.pushNamed(c,r[x]);},
    destinations: const [
      NavigationDestination(icon: Icon(Icons.home), label: "Home"),
      NavigationDestination(icon: Icon(Icons.translate), label: "Traduzir"),
      NavigationDestination(icon: Icon(Icons.menu_book), label: "Aulas"),
      NavigationDestination(icon: Icon(Icons.search), label: "Dicionário"),
      NavigationDestination(icon: Icon(Icons.star), label: "Favoritos"),
    ]);
}
