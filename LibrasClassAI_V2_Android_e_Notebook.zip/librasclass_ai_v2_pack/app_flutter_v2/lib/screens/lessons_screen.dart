
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
class LessonsScreen extends StatefulWidget{ const LessonsScreen({super.key}); @override State<LessonsScreen> createState()=>_LessonsScreenState(); }
class _LessonsScreenState extends State<LessonsScreen>{
  bool loading=true; String error=""; List<dynamic> lessons=[];
  @override void initState(){ super.initState(); load(); }
  Future<void> load() async { setState((){loading=true;error="";}); try{ lessons=await context.read<ApiService>().lessons(); } catch(e){ error="$e"; } if(mounted) setState(()=>loading=false); }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Minhas Aulas"), actions:[IconButton(onPressed:load, icon: const Icon(Icons.refresh))]),
    body: loading? const Center(child:CircularProgressIndicator())
      : error.isNotEmpty ? Center(child:Padding(padding: const EdgeInsets.all(16), child: Text("Falha: $error", textAlign: TextAlign.center)))
      : ListView.separated(itemCount: lessons.length, separatorBuilder:(_,__)=>const Divider(height:1), itemBuilder:(c,i){ final l=lessons[i] as Map<String,dynamic>; final count=(l["items"] as List).length; return ListTile(title: Text(l["title"].toString()), subtitle: Text("${l["subject"]} • $count itens"), trailing: const Icon(Icons.play_circle_fill), onTap: ()=>Navigator.pushNamed(c, "/lesson_player", arguments: l)); }),
    bottomNavigationBar: const _Bottom(2),
  );
}
class _Bottom extends StatelessWidget{ final int i; const _Bottom(this.i,{super.key});
  @override Widget build(BuildContext c)=>NavigationBar(selectedIndex:i,onDestinationSelected:(x){ final r=["/","/translator","/lessons","/dictionary","/favorites"]; Navigator.pushNamed(c,r[x]);},
  destinations: const [NavigationDestination(icon: Icon(Icons.home),label:"Home"),NavigationDestination(icon: Icon(Icons.translate),label:"Traduzir"),NavigationDestination(icon: Icon(Icons.menu_book),label:"Aulas"),NavigationDestination(icon: Icon(Icons.search),label:"Dicionário"),NavigationDestination(icon: Icon(Icons.star),label:"Favoritos")]); }
