
import 'package:flutter/material.dart';
class FavoritesScreen extends StatelessWidget{
  const FavoritesScreen({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text("Favoritos")),
    body: ListView(children: const [
      ListTile(leading: Icon(Icons.star,color: Colors.amber), title: Text("Bom dia turma")),
      ListTile(leading: Icon(Icons.star,color: Colors.amber), title: Text("Abram o caderno")),
      ListTile(leading: Icon(Icons.star,color: Colors.amber), title: Text("Prestem atenção no quadro")),
    ]),
    bottomNavigationBar: const _Bottom(4),
  );
}
class _Bottom extends StatelessWidget{ final int i; const _Bottom(this.i,{super.key});
  @override Widget build(BuildContext c)=>NavigationBar(selectedIndex:i,onDestinationSelected:(x){ final r=["/","/translator","/lessons","/dictionary","/favorites"]; Navigator.pushNamed(c,r[x]);},
  destinations: const [NavigationDestination(icon: Icon(Icons.home),label:"Home"),NavigationDestination(icon: Icon(Icons.translate),label:"Traduzir"),NavigationDestination(icon: Icon(Icons.menu_book),label:"Aulas"),NavigationDestination(icon: Icon(Icons.search),label:"Dicionário"),NavigationDestination(icon: Icon(Icons.star),label:"Favoritos")]); }
