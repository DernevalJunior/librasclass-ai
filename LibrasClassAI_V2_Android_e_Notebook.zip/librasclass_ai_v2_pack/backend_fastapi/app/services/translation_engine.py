
import json, os, re
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
STOP = {"vamos","vou","vai","um","uma","o","a","os","as","de","do","da","e","no","na","nos","nas"}
def _n(s:str):
    s=s.lower().strip()
    s=re.sub(r'[\.,;:!?"()\[\]{}]', ' ', s)
    rep={"ç":"c","á":"a","à":"a","ã":"a","â":"a","é":"e","ê":"e","í":"i","ó":"o","ô":"o","õ":"o","ú":"u"}
    for k,v in rep.items(): s=s.replace(k,v)
    return re.sub(r'\s+',' ',s).strip()
def _idx():
    arr=json.load(open(os.path.join(DATA_DIR,"signs.json"),encoding="utf-8"))
    return {_n(x["word_pt"]):x for x in arr}
def translate_text(text:str):
    idx=_idx(); nt=_n(text)
    toks=[t for t in nt.split() if t and t not in STOP]
    gloss=[]; anim=[]; signs=[]; miss=[]
    for t in toks:
        s=idx.get(t)
        if s:
            gloss.append(s["gloss"]); anim.append(s["animation"]); signs.append(t)
        else:
            gloss.append(t.upper()); anim.append("spell"); signs.append("spell:"+t); miss.append(t)
    return {"normalized":nt,"gloss":" ".join(gloss),"signs":signs,"animations":anim,"missing":miss,"source":"api"}
