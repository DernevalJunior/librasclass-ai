
from fastapi import APIRouter
router = APIRouter()
LESSONS=[{
 "id":1,"title":"Matemática - Frações","subject":"matematica",
 "items":[{"text":"Bom dia turma"},{"text":"Hoje vamos estudar frações"},{"text":"Abram o caderno"},{"text":"Prestem atenção no quadro"},{"text":"Copiem o exercício"}]
}]
@router.get("")
def lessons(): return LESSONS
