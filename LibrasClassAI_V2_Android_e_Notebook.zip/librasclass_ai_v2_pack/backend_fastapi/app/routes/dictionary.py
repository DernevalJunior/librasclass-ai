
import os, json
from fastapi import APIRouter
router = APIRouter()
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
@router.get("/phrases")
def phrases():
    return json.load(open(os.path.join(DATA_DIR,"phrases.json"),encoding="utf-8"))
@router.get("/signs")
def signs():
    return json.load(open(os.path.join(DATA_DIR,"signs.json"),encoding="utf-8"))
