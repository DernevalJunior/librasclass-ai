
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.translation_engine import translate_text
router = APIRouter()
class Req(BaseModel):
    text: str
@router.post("")
def translate(req: Req):
    return translate_text(req.text)
